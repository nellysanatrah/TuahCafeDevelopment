<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'main_admin') {
    die('Access denied.');
}

require_once '../config/database.php';

// Handle Add Staff
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_staff'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $role = $_POST['role'];
    
    $stmt = $conn->prepare("INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $password, $name, $role);
    if ($stmt->execute()) { $success = "Staff added successfully!"; }
    else { $error = "Error adding staff: " . $conn->error; }
    $stmt->close();
}

// Handle Delete Staff
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    if ($id != $_SESSION['user_id']) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $success = "Staff deleted successfully!";
    } else { $error = "You cannot delete your own account!"; }
}

// Handle Update Staff Role
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_role'])) {
    $id = $_POST['id'];
    $role = $_POST['role'];
    $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
    $stmt->bind_param("si", $role, $id);
    $stmt->execute();
    $stmt->close();
    $success = "Staff role updated successfully!";
}

// Fetch all staff
$result = $conn->query("SELECT id, username, name, role, created_at FROM users ORDER BY created_at DESC");

// Get counts for sidebar badges
$job_count = $conn->query("SELECT COUNT(*) as count FROM job_applications")->fetch_assoc()['count'];
$event_count = $conn->query("SELECT COUNT(*) as count FROM event_bookings")->fetch_assoc()['count'];
$reservation_count = $conn->query("SELECT COUNT(*) as count FROM table_reservations")->fetch_assoc()['count'];
$sponsorship_count = $conn->query("SELECT COUNT(*) as count FROM sponsorships")->fetch_assoc()['count'];
$new_jobs = $conn->query("SELECT COUNT(*) as count FROM job_applications WHERE DATE(submitted_at) = CURDATE()")->fetch_assoc()['count'];
$new_events = $conn->query("SELECT COUNT(*) as count FROM event_bookings WHERE tarikh_acara = CURDATE()")->fetch_assoc()['count'];
$new_reservations = $conn->query("SELECT COUNT(*) as count FROM table_reservations WHERE reservation_date = CURDATE()")->fetch_assoc()['count'];
$new_sponsorships = $conn->query("SELECT COUNT(*) as count FROM sponsorships WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Management</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5efe6; display: flex; }

        .sidebar {
            width: 260px;
            background: #4A372E;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-header h2 { font-size: 20px; margin-bottom: 5px; }
        .sidebar-header p { font-size: 12px; opacity: 0.7; }
        .sidebar-nav { list-style: none; padding: 20px 0; }
        .sidebar-nav li { padding: 12px 25px; transition: 0.3s; cursor: pointer; }
        .sidebar-nav li:hover { background: rgba(255,255,255,0.1); }
        .sidebar-nav li.active { background: #6f4e37; border-left: 4px solid #c49b66; }
        .sidebar-nav li a { color: white; text-decoration: none; display: block; font-size: 14px; }
        .sidebar-nav li a i { margin-right: 10px; width: 20px; }
        .badge { background: #c49b66; color: #4A372E; font-size: 10px; font-weight: bold; padding: 2px 6px; border-radius: 10px; margin-left: 10px; }

        .main-content { margin-left: 260px; flex: 1; padding: 20px; }
        .top-header {
            background: white; padding: 15px 25px; border-radius: 10px; margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center;
        }
        .top-header h1 { font-size: 24px; color: #4A372E; }

        .profile-dropdown { position: relative; display: inline-block; }
        .profile-btn { background: #6f4e37; color: white; padding: 8px 15px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 10px; font-size: 14px; border: none; }
        .profile-btn:hover { background: #5a3d2e; }
        .profile-dropdown-content { display: none; position: absolute; right: 0; top: 100%; background: white; min-width: 180px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 8px; z-index: 100; margin-top: 5px; }
        .profile-dropdown-content a { color: #4A372E; padding: 10px 15px; text-decoration: none; display: block; font-size: 14px; }
        .profile-dropdown-content a:hover { background: #f5efe6; border-radius: 8px; }
        .profile-dropdown:hover .profile-dropdown-content { display: block; }

        .add-btn { background: #c49b66; color: white; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; }
        .add-btn:hover { background: #a87d4a; }

        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center; }
        .modal.show { display: flex; }
        .modal-content { background: white; border-radius: 15px; padding: 30px; width: 500px; max-width: 90%; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #f0e6d8; }
        .close-modal { background: none; border: none; font-size: 24px; cursor: pointer; color: #999; }

        .table-card { background: white; border-radius: 15px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #f0e6d8; }
        th { background: #f9f5f0; color: #4A372E; }

        .role-badge { display: inline-block; padding: 4px 10px; border-radius: 15px; font-size: 11px; font-weight: bold; }
        .role-admin { background: #c49b66; color: white; }
        .role-main_admin { background: #6f4e37; color: white; }
        .role-staff { background: #a5a5a5; color: white; }

        .action-btn { padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer; font-size: 12px; text-decoration: none; display: inline-block; }
        .delete-btn { background: #a94442; color: white; }
        .role-select { padding: 5px; border-radius: 5px; border: 1px solid #ddd; font-size: 12px; }
        .success-msg { background: #d4edda; color: #155724; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .error-msg { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; color: #4A372E; font-weight: bold; margin-bottom: 5px; font-size: 14px; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        .btn-submit { background: #6f4e37; color: white; padding: 12px 25px; border: none; border-radius: 8px; cursor: pointer; width: 100%; margin-top: 10px; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header"><h2>Tuah Cafe</h2><p>Admin Panel</p></div>
    <ul class="sidebar-nav">
		<li onclick="location.href='dashboard.php'"><a href="#"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
		<li onclick="location.href='dashboard.php#applications'"><a href="#"><i class="fas fa-briefcase"></i> Job Applications</a><?php if ($new_jobs > 0): ?><span class="badge">+<?php echo $new_jobs; ?></span><?php endif; ?></li>
		<li onclick="location.href='dashboard.php#event-bookings'"><a href="#"><i class="fas fa-calendar"></i> Event Bookings</a><?php if ($new_events > 0): ?><span class="badge">+<?php echo $new_events; ?></span><?php endif; ?></li>
		<li onclick="location.href='dashboard.php#table-reservation'"><a href="#"><i class="fas fa-chair"></i> Table Reservation</a><?php if ($new_reservations > 0): ?><span class="badge">+<?php echo $new_reservations; ?></span><?php endif; ?></li>
		<li onclick="location.href='dashboard.php#sponsorships'"><a href="#"><i class="fas fa-handshake"></i> Sponsorship Applications</a><?php if ($new_sponsorships > 0): ?><span class="badge">+<?php echo $new_sponsorships; ?></span><?php endif; ?></li>
		<li onclick="markAllBeforeLeave()"><a href="#"><i class="fas fa-users"></i> Staff Management</a></li>
	</ul>
</div>

<div class="main-content">
    <div class="top-header">
        <div><h1>Staff Management</h1><p>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?> (<?php echo htmlspecialchars($_SESSION['role']); ?>)</p></div>
        <div class="profile-dropdown">
            <button class="profile-btn"><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['name']); ?> <i class="fas fa-chevron-down"></i></button>
            <div class="profile-dropdown-content">
                <a href="profile.php"><i class="fas fa-user"></i> My Profile</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <?php if (isset($success)): ?><div class="success-msg"><?php echo $success; ?></div><?php endif; ?>
    <?php if (isset($error)): ?><div class="error-msg"><?php echo $error; ?></div><?php endif; ?>

    <div class="table-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2>Staff List</h2>
            <button class="add-btn" onclick="openModal()">+ Add New Staff</button>
        </div>
        <table>
            <thead><tr><th>ID</th><th>Username</th><th>Name</th><th>Role</th><th>Created At</th><th>Action</th></tr></thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><span class="role-badge role-<?php echo $row['role']; ?>"><?php echo ucfirst(str_replace('_', ' ', $row['role'])); ?></span></td>
                        <td><?php echo date('d/m/Y', strtotime($row['created_at'])); ?></td>
                        <td>
                            <form method="POST" style="display:inline">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <select name="role" class="role-select" onchange="this.form.submit()">
                                    <option value="staff" <?php echo $row['role'] == 'staff' ? 'selected' : ''; ?>>Staff</option>
                                    <option value="admin" <?php echo $row['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                    <option value="main_admin" <?php echo $row['role'] == 'main_admin' ? 'selected' : ''; ?>>Main Admin</option>
                                </select>
                                <input type="hidden" name="update_role" value="1">
                            </form>
                            <?php if ($row['id'] != $_SESSION['user_id']): ?>
                                <a href="?delete=<?php echo $row['id']; ?>" class="action-btn delete-btn" onclick="return confirm('Delete this staff?')">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align:center">No staff found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="addStaffModal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h2>Add New Staff</h2><button class="close-modal" onclick="closeModal()">&times;</button></div>
        <form method="POST">
            <div class="form-group"><label>Username *</label><input type="text" name="username" required></div>
            <div class="form-group"><label>Password *</label><input type="password" name="password" required></div>
            <div class="form-group"><label>Full Name *</label><input type="text" name="name" required></div>
            <div class="form-group"><label>Role *</label><select name="role" required><option value="staff">Staff</option><option value="admin">Admin</option><option value="main_admin">Main Admin</option></select></div>
            <button type="submit" name="add_staff" class="btn-submit">Add Staff</button>
        </form>
    </div>
</div>

<script>
function markAllBeforeLeave() {
    fetch('mark_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'table=job_applications&mark_all=1'
    });
    fetch('mark_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'table=event_bookings&mark_all=1'
    });
    fetch('mark_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'table=table_reservations&mark_all=1'
    });
    fetch('mark_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'table=komuniti_events&mark_all=1'
    });
    window.location.href = 'admin_staff.php';
}
</script>
</body>
</html>