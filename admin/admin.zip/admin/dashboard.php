<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$role = $_SESSION['role'];
$name = $_SESSION['name'];
require_once '../config/database.php';

// Get counts for summaries (total counts)
$job_count = $conn->query("SELECT COUNT(*) as count FROM job_applications")->fetch_assoc()['count'];
$event_count = $conn->query("SELECT COUNT(*) as count FROM event_bookings")->fetch_assoc()['count'];
$reservation_count = $conn->query("SELECT COUNT(*) as count FROM table_reservations")->fetch_assoc()['count'];
$sponsorship_count = $conn->query("SELECT COUNT(*) as count FROM komuniti_events")->fetch_assoc()['count'];

// Get UNREAD counts for badges (only for tables that have is_read column)
$new_jobs = $conn->query("SELECT COUNT(*) as count FROM job_applications WHERE is_read = 0")->fetch_assoc()['count'];
$new_events = $conn->query("SELECT COUNT(*) as count FROM event_bookings WHERE is_read = 0")->fetch_assoc()['count'];
$new_reservations = $conn->query("SELECT COUNT(*) as count FROM table_reservations WHERE is_read = 0")->fetch_assoc()['count'];
$new_sponsorships = $conn->query("SELECT COUNT(*) as count FROM komuniti_events WHERE is_read = 0")->fetch_assoc()['count'];

// Get recent unread items for announcements
$recent_jobs = $conn->query("SELECT id, full_name, applying_position, submitted_at FROM job_applications WHERE is_read = 0 ORDER BY submitted_at DESC LIMIT 10");
$recent_events = $conn->query("SELECT id, nama_penuh as customer_name, jenis_acara as event_type, tarikh_acara as event_date FROM event_bookings WHERE is_read = 0 ORDER BY tarikh_acara DESC LIMIT 10");
$recent_reservations = $conn->query("SELECT id, full_name as customer_name, guests_count as guests, reservation_date FROM table_reservations WHERE is_read = 0 ORDER BY reservation_date DESC LIMIT 10");
$recent_sponsorships = $conn->query("SELECT id, name, proposal FROM komuniti_events WHERE is_read = 0 ORDER BY id DESC LIMIT 10");

$total_new = $new_jobs + $new_events + $new_reservations + $new_sponsorships;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Cafe Admin Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5efe6; display: flex; }

        .sidebar {
            width: 260px;
            background: #4A372E;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-header h2 { font-size: 20px; margin-bottom: 5px; }
        .sidebar-header p { font-size: 12px; opacity: 0.7; }
        .sidebar-nav { list-style: none; padding: 20px 0; }
        .sidebar-nav li { padding: 12px 25px; transition: 0.3s; cursor: pointer; }
        .sidebar-nav li:hover { background: rgba(255,255,255,0.1); }
        .sidebar-nav li.active { background: #6f4e37; border-left: 4px solid #c49b66; }
        .sidebar-nav li a { color: white; text-decoration: none; display: block; font-size: 14px; }
        .sidebar-nav li a i { margin-right: 10px; width: 20px; }
        .badge { background: #c49b66; color: #4A372E; font-size: 10px; font-weight: bold; padding: 2px 6px; border-radius: 10px; margin-left: 10px; }

        .main-content { margin-left: 260px; flex: 1; padding: 20px; }
        .top-header {
            background: white; padding: 15px 25px; border-radius: 10px; margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center;
        }
        .top-header h1 { font-size: 24px; color: #4A372E; }
        .top-header p { color: #666; font-size: 14px; margin-top: 5px; }

        .profile-dropdown { position: relative; display: inline-block; }
        .profile-btn { background: #6f4e37; color: white; padding: 8px 15px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 10px; font-size: 14px; border: none; }
        .profile-btn:hover { background: #5a3d2e; }
        .profile-dropdown-content { display: none; position: absolute; right: 0; top: 100%; background: white; min-width: 180px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 8px; z-index: 100; margin-top: 5px; }
        .profile-dropdown-content a { color: #4A372E; padding: 10px 15px; text-decoration: none; display: block; font-size: 14px; }
        .profile-dropdown-content a:hover { background: #f5efe6; border-radius: 8px; }
        .profile-dropdown:hover .profile-dropdown-content { display: block; }

        .notification-bell { position: relative; cursor: pointer; font-size: 20px; color: #6f4e37; margin-right: 20px; }
        .notification-count { position: absolute; top: -8px; right: -10px; background: #c49b66; color: white; font-size: 10px; font-weight: bold; padding: 2px 6px; border-radius: 10px; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); text-align: center; }
        .stat-number { font-size: 32px; font-weight: bold; color: #6f4e37; }
        .stat-label { color: #888; font-size: 14px; margin-top: 5px; }

        .announcements-section { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 30px; }
        .announcements-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #f0e6d8; padding-bottom: 10px; margin-bottom: 15px; }
        .announcements-header h3 { color: #4A372E; }
        .new-badge { background: #c49b66; color: white; font-size: 11px; padding: 2px 8px; border-radius: 15px; }
        .announcement-item { padding: 12px 0; border-bottom: 1px solid #f0e6d8; display: flex; justify-content: space-between; align-items: center; }
        .announcement-item:last-child { border-bottom: none; }
        .announcement-content { flex: 1; }
        .announcement-title { font-weight: bold; color: #4A372E; margin-bottom: 3px; }
        .announcement-detail { font-size: 13px; color: #888; }
        .announcement-time { font-size: 11px; color: #c49b66; margin-right: 10px; }
        .view-link { background: #6f4e37; color: white; padding: 5px 12px; border-radius: 5px; text-decoration: none; font-size: 12px; }
        .view-link:hover { background: #5a3d2e; }

        .content-section { display: none; background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .content-section.active { display: block; }
        .content-section h2 { color: #4A372E; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #f0e6d8; }
        #dashboard-view { display: block; }
        #dashboard-view.hide { display: none; }
        
        .btn { padding: 8px 12px; border: none; border-radius: 8px; color: white; cursor: pointer; font-size: 12px; }
        .edit-btn { background: #c49b66; }
        .delete-btn { background: #a94442; }
        .approve-btn { background: #28a745; }
        .reject-btn { background: #dc3545; }
        .view-btn { background: #17a2b8; }
        .status { padding: 5px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; display: inline-block; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        table { width: 100%; border-collapse: collapse; background: white; border-radius: 10px; overflow: hidden; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f9f5f0; font-weight: bold; }
        .container { background: white; padding: 25px; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
        h1 { color: #6f4e37; margin-bottom: 20px; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script>
        function markAsRead(id, table, sectionId, element) {
            fetch('mark_read.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'table=' + table + '&id=' + id
            });
            
            const announcementItem = event.target.closest('.announcement-item');
            if (announcementItem) {
                announcementItem.remove();
            }
            
            const announcementsContainer = document.querySelector('.announcements-section .announcement-item');
            if (!announcementsContainer) {
                document.querySelector('.announcements-section .new-badge').style.display = 'none';
                document.querySelector('.announcements-section .announcements-header').innerHTML = '<h3><i class="fas fa-bullhorn"></i> Announcements</h3><span class="new-badge" style="display:none;">0 new</span>';
                const emptyMsg = document.createElement('div');
                emptyMsg.className = 'announcement-item';
                emptyMsg.innerHTML = '<div class="announcement-content"><div class="announcement-detail" style="text-align:center; color:#999;">No new announcements. Everything is up to date!</div></div>';
                document.querySelector('.announcements-section').appendChild(emptyMsg);
            }
            
            showSection(sectionId, element, table);
        }
        
        function markAllAsRead(table, element) {
            fetch('mark_read.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'table=' + table
            });
            
            // Remove the badge from the sidebar immediately
            const badge = element.querySelector('.badge');
            if (badge) {
                badge.remove();
            }
        }
        
        function showSection(sectionId, element, tableName) {
            // Mark all items in this table as read and remove badge
            if (tableName) {
                markAllAsRead(tableName, element);
            }
            
            const dashboardView = document.getElementById('dashboard-view');
            const contentSections = document.querySelectorAll('.content-section');
            if (sectionId === 'dashboard') {
                dashboardView.classList.remove('hide');
                contentSections.forEach(section => section.classList.remove('active'));
            } else {
                dashboardView.classList.add('hide');
                contentSections.forEach(section => section.classList.remove('active'));
                document.getElementById(sectionId).classList.add('active');
            }
            document.querySelectorAll('.sidebar-nav li').forEach(li => li.classList.remove('active'));
            if (element) element.classList.add('active');
            
            // Update URL hash without causing page jump
            history.pushState(null, null, '#' + sectionId);
        }
        
        // Function to show section based on URL hash on page load
        function showSectionFromHash() {
            var hash = window.location.hash;
            if (hash && hash !== '#') {
                var sectionId = hash.substring(1);
                var sectionMap = {
                    'applications': 1,
                    'event-bookings': 2,
                    'table-reservation': 3,
                    'sponsorships': 4
                };
                var index = sectionMap[sectionId];
                if (index !== undefined) {
                    var navItems = document.querySelectorAll('.sidebar-nav li');
                    var navElement = navItems[index];
                    if (navElement) {
                        showSection(sectionId, navElement, '');
                    }
                }
            }
        }
        
        // Run when page loads
        document.addEventListener('DOMContentLoaded', function() {
            showSectionFromHash();
        });
    </script>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <h2>Tuah Cafe</h2>
        <p>Admin Panel</p>
    </div>
    <ul class="sidebar-nav">
        <li class="active" onclick="showSection('dashboard', this, '')"><a href="#"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li onclick="showSection('applications', this, 'job_applications')"><a href="#"><i class="fas fa-briefcase"></i> Job Applications</a><?php if ($new_jobs > 0): ?><span class="badge"><?php echo $new_jobs; ?></span><?php endif; ?></li>
        <li onclick="showSection('event-bookings', this, 'event_bookings')"><a href="#"><i class="fas fa-calendar"></i> Event Bookings</a><?php if ($new_events > 0): ?><span class="badge"><?php echo $new_events; ?></span><?php endif; ?></li>
        <li onclick="showSection('table-reservation', this, 'table_reservations')"><a href="#"><i class="fas fa-chair"></i> Table Reservation</a><?php if ($new_reservations > 0): ?><span class="badge"><?php echo $new_reservations; ?></span><?php endif; ?></li>
        <li onclick="showSection('sponsorships', this, 'komuniti_events')"><a href="#"><i class="fas fa-handshake"></i> Sponsorship Applications</a><?php if ($new_sponsorships > 0): ?><span class="badge"><?php echo $new_sponsorships; ?></span><?php endif; ?></li>
        <?php if ($role == 'admin' || $role == 'main_admin'): ?>
        <li onclick="location.href='admin_staff.php'"><a href="#"><i class="fas fa-users"></i> Staff Management</a></li>
        <?php endif; ?>
    </ul>
</div>

<div class="main-content">
    <div class="top-header">
        <div><h1>Dashboard</h1><p>Welcome, <?php echo htmlspecialchars($name); ?> (<?php echo htmlspecialchars($role); ?>)</p></div>
        <div style="display: flex; align-items: center;">
            <div class="notification-bell"><i class="fas fa-bell"></i><?php if ($total_new > 0): ?><span class="notification-count"><?php echo $total_new; ?></span><?php endif; ?></div>
            <div class="profile-dropdown">
                <button class="profile-btn"><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($name); ?> <i class="fas fa-chevron-down"></i></button>
                <div class="profile-dropdown-content">
                    <a href="profile.php"><i class="fas fa-user"></i> My Profile</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div id="dashboard-view">
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-number"><?php echo $job_count; ?></div><div class="stat-label">Job Applications</div></div>
            <div class="stat-card"><div class="stat-number"><?php echo $event_count; ?></div><div class="stat-label">Event Bookings</div></div>
            <div class="stat-card"><div class="stat-number"><?php echo $reservation_count; ?></div><div class="stat-label">Table Reservations</div></div>
            <div class="stat-card"><div class="stat-number"><?php echo $sponsorship_count; ?></div><div class="stat-label">Sponsorship Applications</div></div>
        </div>

        <div class="announcements-section">
            <div class="announcements-header">
                <h3><i class="fas fa-bullhorn"></i> Announcements</h3>
                <?php if ($total_new > 0): ?>
                <span class="new-badge"><?php echo $total_new; ?> new</span>
                <?php else: ?>
                <span class="new-badge" style="display:none;">0 new</span>
                <?php endif; ?>
            </div>
            
            <?php if ($recent_jobs && $recent_jobs->num_rows > 0): ?>
                <?php while($job = $recent_jobs->fetch_assoc()): ?>
                <div class="announcement-item">
                    <div class="announcement-content">
                        <div class="announcement-title"><i class="fas fa-briefcase"></i> New Job Application</div>
                        <div class="announcement-detail"><?php echo htmlspecialchars($job['full_name']); ?> applied for <?php echo htmlspecialchars($job['applying_position']); ?></div>
                    </div>
                    <div>
                        <span class="announcement-time"><?php echo date('d/m/Y', strtotime($job['submitted_at'])); ?></span>
                        <a href="#" onclick="markAsRead(<?php echo $job['id']; ?>, 'job_applications', 'applications', document.querySelector('.sidebar-nav li:nth-child(2)')); return false;" class="view-link">View</a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php endif; ?>
            
            <?php if ($recent_events && $recent_events->num_rows > 0): ?>
                <?php while($event = $recent_events->fetch_assoc()): ?>
                <div class="announcement-item">
                    <div class="announcement-content">
                        <div class="announcement-title"><i class="fas fa-calendar"></i> New Event Booking</div>
                        <div class="announcement-detail"><?php echo htmlspecialchars($event['customer_name']); ?> booked <?php echo htmlspecialchars($event['event_type']); ?></div>
                    </div>
                    <div>
                        <span class="announcement-time"><?php echo date('d/m/Y', strtotime($event['event_date'])); ?></span>
                        <a href="#" onclick="markAsRead(<?php echo $event['id']; ?>, 'event_bookings', 'event-bookings', document.querySelector('.sidebar-nav li:nth-child(3)')); return false;" class="view-link">View</a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php endif; ?>
            
            <?php if ($recent_reservations && $recent_reservations->num_rows > 0): ?>
                <?php while($reservation = $recent_reservations->fetch_assoc()): ?>
                <div class="announcement-item">
                    <div class="announcement-content">
                        <div class="announcement-title"><i class="fas fa-chair"></i> New Table Reservation</div>
                        <div class="announcement-detail"><?php echo htmlspecialchars($reservation['customer_name']); ?> reserved a table for <?php echo $reservation['guests']; ?> guests</div>
                    </div>
                    <div>
                        <span class="announcement-time"><?php echo date('d/m/Y', strtotime($reservation['reservation_date'])); ?></span>
                        <a href="#" onclick="markAsRead(<?php echo $reservation['id']; ?>, 'table_reservations', 'table-reservation', document.querySelector('.sidebar-nav li:nth-child(4)')); return false;" class="view-link">View</a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php endif; ?>
            
            <?php if ($recent_sponsorships && $recent_sponsorships->num_rows > 0): ?>
                <?php while($sponsor = $recent_sponsorships->fetch_assoc()): ?>
                <div class="announcement-item">
                    <div class="announcement-content">
                        <div class="announcement-title"><i class="fas fa-handshake"></i> New Sponsorship Application</div>
                        <div class="announcement-detail"><?php echo htmlspecialchars($sponsor['name']); ?> submitted a sponsorship application</div>
                    </div>
                    <div>
                        <span class="announcement-time"><?php echo date('d/m/Y'); ?></span>
                        <a href="#" onclick="markAsRead(<?php echo $sponsor['id']; ?>, 'komuniti_events', 'sponsorships', document.querySelector('.sidebar-nav li:nth-child(5)')); return false;" class="view-link">View</a>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php endif; ?>
            
            <?php if ($total_new == 0): ?>
                <div class="announcement-item">
                    <div class="announcement-content">
                        <div class="announcement-detail" style="text-align:center; color:#999;">No new announcements. Everything is up to date!</div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div id="applications" class="content-section"><h2>Job Applications</h2><?php include 'admin_job_application.php'; ?></div>
    <div id="event-bookings" class="content-section"><h2>Event Bookings</h2><?php include 'admin_event_bookings.php'; ?></div>
    <div id="table-reservation" class="content-section"><h2>Table Reservations</h2><?php include 'admin_table_reservation.php'; ?></div>
    <div id="sponsorships" class="content-section"><h2>Sponsorship Applications</h2><?php include 'admin_sponsorships.php'; ?></div>
</div>

<script>
// Function to show section based on URL hash on page load
function showSectionFromHash() {
    var hash = window.location.hash;
    if (hash && hash !== '#') {
        var sectionId = hash.substring(1);
        var sectionMap = {
            'applications': 1,
            'event-bookings': 2,
            'table-reservation': 3,
            'sponsorships': 4
        };
        var index = sectionMap[sectionId];
        if (index !== undefined) {
            var navItems = document.querySelectorAll('.sidebar-nav li');
            var navElement = navItems[index];
            if (navElement) {
                showSection(sectionId, navElement, '');
            }
        }
    }
}

// Run when page loads
document.addEventListener('DOMContentLoaded', function() {
    showSectionFromHash();
});
</script>

</body>
</html>