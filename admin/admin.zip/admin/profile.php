<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once '../config/database.php';

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

$stmt = $conn->prepare("SELECT id, username, name, role, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    
    $check = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
    $check->bind_param("si", $username, $user_id);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $error = "Username already taken!";
    } else {
        $update = $conn->prepare("UPDATE users SET name = ?, username = ? WHERE id = ?");
        $update->bind_param("ssi", $name, $username, $user_id);
        if ($update->execute()) {
            $_SESSION['name'] = $name;
            $success = "Profile updated successfully!";
            $user['name'] = $name;
            $user['username'] = $username;
        } else { $error = "Error updating profile."; }
        $update->close();
    }
    $check->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $pass_stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $pass_stmt->bind_param("i", $user_id);
    $pass_stmt->execute();
    $current_hash = $pass_stmt->get_result()->fetch_assoc()['password'];
    $pass_stmt->close();
    
    if ($current_password != $current_hash) {
        $password_error = "Current password is incorrect!";
    } elseif ($new_password != $confirm_password) {
        $password_error = "New passwords do not match!";
    } elseif (strlen($new_password) < 4) {
        $password_error = "Password must be at least 4 characters!";
    } else {
        $update_pass = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $update_pass->bind_param("si", $new_password, $user_id);
        if ($update_pass->execute()) { $password_success = "Password changed successfully!"; }
        else { $password_error = "Error changing password."; }
        $update_pass->close();
    }
}

// Get counts for sidebar badges
$job_count = $conn->query("SELECT COUNT(*) as count FROM job_applications")->fetch_assoc()['count'];
$event_count = $conn->query("SELECT COUNT(*) as count FROM event_bookings")->fetch_assoc()['count'];
$reservation_count = $conn->query("SELECT COUNT(*) as count FROM table_reservations")->fetch_assoc()['count'];
$sponsorship_count = $conn->query("SELECT COUNT(*) as count FROM sponsorships")->fetch_assoc()['count'];
$new_jobs = $conn->query("SELECT COUNT(*) as count FROM job_applications WHERE DATE(submitted_at) = CURDATE()")->fetch_assoc()['count'];
$new_events = $conn->query("SELECT COUNT(*) as count FROM event_bookings WHERE tarikh_acara = CURDATE()")->fetch_assoc()['count'];
$new_reservations = $conn->query("SELECT COUNT(*) as count FROM table_reservations WHERE reservation_date = CURDATE()")->fetch_assoc()['count'];
$new_sponsorships = $conn->query("SELECT COUNT(*) as count FROM sponsorships WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5efe6; display: flex; }

        .sidebar {
            width: 260px;
            background: #4A372E;
            color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            overflow-y: auto;
        }
        .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-header h2 { font-size: 20px; margin-bottom: 5px; }
        .sidebar-header p { font-size: 12px; opacity: 0.7; }
        .sidebar-nav { list-style: none; padding: 20px 0; }
        .sidebar-nav li { padding: 12px 25px; transition: 0.3s; cursor: pointer; }
        .sidebar-nav li:hover { background: rgba(255,255,255,0.1); }
        .sidebar-nav li a { color: white; text-decoration: none; display: block; font-size: 14px; }
        .sidebar-nav li a i { margin-right: 10px; width: 20px; }
        .badge { background: #c49b66; color: #4A372E; font-size: 10px; font-weight: bold; padding: 2px 6px; border-radius: 10px; margin-left: 10px; }

        .main-content { margin-left: 260px; flex: 1; padding: 20px; }
        .top-header {
            background: white; padding: 15px 25px; border-radius: 10px; margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center;
        }
        .top-header h1 { font-size: 24px; color: #4A372E; }

        .profile-dropdown { position: relative; display: inline-block; }
        .profile-btn { background: #6f4e37; color: white; padding: 8px 15px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 10px; font-size: 14px; border: none; }
        .profile-btn:hover { background: #5a3d2e; }
        .profile-dropdown-content { display: none; position: absolute; right: 0; top: 100%; background: white; min-width: 180px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 8px; z-index: 100; margin-top: 5px; }
        .profile-dropdown-content a { color: #4A372E; padding: 10px 15px; text-decoration: none; display: block; font-size: 14px; }
        .profile-dropdown-content a:hover { background: #f5efe6; border-radius: 8px; }
        .profile-dropdown:hover .profile-dropdown-content { display: block; }

        .profile-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .profile-card h2 { color: #4A372E; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #f0e6d8; }
        .info-row { display: flex; margin-bottom: 15px; padding: 10px; background: #f9f5f0; border-radius: 8px; }
        .info-label { width: 120px; font-weight: bold; color: #4A372E; }
        .info-value { flex: 1; color: #666; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; color: #4A372E; font-weight: bold; margin-bottom: 5px; font-size: 14px; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        .btn-submit { background: #6f4e37; color: white; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; margin-top: 10px; }
        .success-msg { background: #d4edda; color: #155724; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .error-msg { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .two-columns { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        .role-badge { display: inline-block; padding: 4px 10px; border-radius: 15px; font-size: 11px; font-weight: bold; }
        .role-admin { background: #c49b66; color: white; }
        .role-main_admin { background: #6f4e37; color: white; }
        .role-staff { background: #a5a5a5; color: white; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header"><h2>Tuah Cafe</h2><p>Admin Panel</p></div>
    <ul class="sidebar-nav">
        <li onclick="location.href='dashboard.php'"><a href="#"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li onclick="location.href='dashboard.php#applications'"><a href="#"><i class="fas fa-briefcase"></i> Job Applications</a><?php if ($new_jobs > 0): ?><span class="badge">+<?php echo $new_jobs; ?></span><?php endif; ?></li>
        <li onclick="location.href='dashboard.php#event-bookings'"><a href="#"><i class="fas fa-calendar"></i> Event Bookings</a><?php if ($new_events > 0): ?><span class="badge">+<?php echo $new_events; ?></span><?php endif; ?></li>
        <li onclick="location.href='dashboard.php#table-reservation'"><a href="#"><i class="fas fa-chair"></i> Table Reservation</a><?php if ($new_reservations > 0): ?><span class="badge">+<?php echo $new_reservations; ?></span><?php endif; ?></li>
        <li onclick="location.href='dashboard.php#sponsorships'"><a href="#"><i class="fas fa-handshake"></i> Sponsorship Applications</a><?php if ($new_sponsorships > 0): ?><span class="badge">+<?php echo $new_sponsorships; ?></span><?php endif; ?></li>
        <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'main_admin'): ?>
        <li onclick="location.href='admin_staff.php'"><a href="#"><i class="fas fa-users"></i> Staff Management</a></li>
        <?php endif; ?>
    </ul>
</div>

<div class="main-content">
    <div class="top-header">
        <h1>My Profile</h1>
        <div class="profile-dropdown">
            <button class="profile-btn"><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['name']); ?> <i class="fas fa-chevron-down"></i></button>
            <div class="profile-dropdown-content">
                <a href="profile.php"><i class="fas fa-user"></i> My Profile</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <?php if (isset($success)): ?><div class="success-msg"><?php echo $success; ?></div><?php endif; ?>
    <?php if (isset($error)): ?><div class="error-msg"><?php echo $error; ?></div><?php endif; ?>

    <div class="two-columns">
        <div class="profile-card">
            <h2><i class="fas fa-user"></i> Profile Information</h2>
            <div class="info-row"><div class="info-label">Username:</div><div class="info-value"><?php echo htmlspecialchars($user['username']); ?></div></div>
            <div class="info-row"><div class="info-label">Full Name:</div><div class="info-value"><?php echo htmlspecialchars($user['name']); ?></div></div>
            <div class="info-row"><div class="info-label">Role:</div><div class="info-value"><span class="role-badge role-<?php echo $user['role']; ?>"><?php echo ucfirst(str_replace('_', ' ', $user['role'])); ?></span></div></div>
            <div class="info-row"><div class="info-label">Member Since:</div><div class="info-value"><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></div></div>
            <form method="POST" style="margin-top: 20px;">
                <div class="form-group"><label>Full Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required></div>
                <div class="form-group"><label>Username</label><input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required></div>
                <button type="submit" name="update_profile" class="btn-submit">Update Profile</button>
            </form>
        </div>

        <div class="profile-card">
            <h2><i class="fas fa-lock"></i> Change Password</h2>
            <?php if (isset($password_success)): ?><div class="success-msg"><?php echo $password_success; ?></div><?php endif; ?>
            <?php if (isset($password_error)): ?><div class="error-msg"><?php echo $password_error; ?></div><?php endif; ?>
            <form method="POST">
                <div class="form-group"><label>Current Password</label><input type="password" name="current_password" required></div>
                <div class="form-group"><label>New Password</label><input type="password" name="new_password" required></div>
                <div class="form-group"><label>Confirm New Password</label><input type="password" name="confirm_password" required></div>
                <button type="submit" name="change_password" class="btn-submit">Change Password</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>